package com.whqp.tgmj.tools;

public interface NetworkConnectChangeObserver {
    void onNetConnected(int networkType);
}
