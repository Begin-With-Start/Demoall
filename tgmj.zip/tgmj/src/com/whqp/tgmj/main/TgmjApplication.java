package com.whqp.tgmj.main;

import android.app.Application;

import com.whqp.tgmj.tools.NetworkConnectChangeReceiver;
import com.whqp.tgmj.tools.NetworkManager;

public class TgmjApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        NetworkConnectChangeReceiver.registerReceiver(this);
        NetworkManager.CreateInstance(this);
        NetworkManager.getInstance().Init();
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
        NetworkConnectChangeReceiver.unregisterReceiver(this);
    }
}
