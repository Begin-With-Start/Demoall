/****************************************************************************
 Copyright (c) 2015-2016 Chukong Technologies Inc.
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.

 http://www.cocos2d-x.org

 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/
package com.whqp.tgmj;

import org.cocos2dx.javascript.SDKWrapper;
import org.cocos2dx.lib.Cocos2dxActivity;
import org.cocos2dx.lib.Cocos2dxGLSurfaceView;
import org.cocos2dx.lib.Cocos2dxJavascriptJavaBridge;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.opengl.GLException;
import android.os.Build;
import android.os.Bundle;

import com.cocos.analytics.CAAgent;
import com.tencent.mm.opensdk.modelmsg.SendAuth;
import com.tencent.mm.opensdk.modelmsg.SendMessageToWX;
import com.tencent.mm.opensdk.modelmsg.WXImageObject;
import com.tencent.mm.opensdk.modelmsg.WXMediaMessage;
import com.tencent.mm.opensdk.modelmsg.WXWebpageObject;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;
import com.whqp.tgmj.tools.Constants;
import com.whqp.tgmj.tools.NetworkConnectChangeObserver;
import com.whqp.tgmj.tools.NetworkConnectChangeReceiver;
import com.whqp.tgmj.tools.VibratorUtil;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.view.View;

import java.io.IOException;
import java.nio.IntBuffer;
import java.util.List;

import javax.microedition.khronos.opengles.GL10;

public class AppActivity extends Cocos2dxActivity implements NetworkConnectChangeObserver {
    private static final int RETURN_MSG_TYPE_LOGIN = 1;
    private static final int RETURN_MSG_TYPE_SHARE = 2;

    private static final int THUMB_SIZE = 128;

    private static final String appId = "wx92b95b6117970daa";

    public static IWXAPI mWxApi;

    public static AppActivity instance = null;

    LocationManager locationManager;

    private boolean toGetLocation = false;

    private MediaRecorder mediaRecorder;
    private boolean isRecording;

    Handler handler = new Handler();
    Runnable runnableRec;

    private MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Workaround in https://stackoverflow.com/questions/16283079/re-launch-of-activity-on-home-button-but-only-the-first-time/16447508
        if (!isTaskRoot()) {
            // Android launched another instance of the root activity into an existing task
            //  so just quietly finish and go away, dropping the user back into the activity
            //  at the top of the stack (ie: the last state of this task)
            // Don't need to finish it again since it's finished in super.onCreate .
            return;
        }
        instance = this;

        // DO OTHER INITIALIZATION BELOW
        SDKWrapper.getInstance().init(this);
        CAAgent.enableDebug(false);

        //注册到微信
        registToWX();

        //网络监听 观察者订阅
        NetworkConnectChangeReceiver.registerObserver(this);

        //摇一摇事件监听
        registerShakeListener();

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (toGetLocation) {
            beginLocatioon();
        }
    }

    @Override
    public Cocos2dxGLSurfaceView onCreateView() {
        Cocos2dxGLSurfaceView glSurfaceView = new Cocos2dxGLSurfaceView(this);
        // TestCpp should create stencil buffer
        glSurfaceView.setEGLConfigChooser(5, 6, 5, 0, 16, 8);

        SDKWrapper.getInstance().setGLSurfaceView(glSurfaceView);

        return glSurfaceView;
    }

    @Override
    protected void onResume() {
        super.onResume();
        SDKWrapper.getInstance().onResume();
        if (CAAgent.isInited())
            CAAgent.onResume(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        SDKWrapper.getInstance().onPause();
        if (CAAgent.isInited())
            CAAgent.onPause(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        SDKWrapper.getInstance().onDestroy();
        if (CAAgent.isInited())
            CAAgent.onDestroy();
        NetworkConnectChangeReceiver.unregisterObserver(this);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        SDKWrapper.getInstance().onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        SDKWrapper.getInstance().onNewIntent(intent);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        SDKWrapper.getInstance().onRestart();
    }

    @Override
    protected void onStop() {
        super.onStop();
        SDKWrapper.getInstance().onStop();
    }

    @Override
    public void onBackPressed() {
        SDKWrapper.getInstance().onBackPressed();
        //super.onBackPressed();
        moveTaskToBack(false);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        SDKWrapper.getInstance().onConfigurationChanged(newConfig);
        super.onConfigurationChanged(newConfig);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        SDKWrapper.getInstance().onRestoreInstanceState(savedInstanceState);
        super.onRestoreInstanceState(savedInstanceState);

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        SDKWrapper.getInstance().onSaveInstanceState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onStart() {
        SDKWrapper.getInstance().onStart();
        super.onStart();
    }

    public static void OnBackPressed() {
        instance.onBackPressed();
    }


    public static void runJs(String js) {
        final String jsStr = js;
        instance.runOnGLThread(new Runnable() {
            @Override
            public void run() {
                Cocos2dxJavascriptJavaBridge.evalString(jsStr);
            }
        });
    }


    public void registToWX() {
        //AppConst.WEIXIN.APP_ID是指你应用在微信开放平台上的AppID
        mWxApi = WXAPIFactory.createWXAPI(this, appId, true);
        // 将该app注册到微信
        mWxApi.registerApp(appId);
    }

    public void wxLogin(String scope, String state) {
        if (!mWxApi.isWXAppInstalled()) {
            //UIUtils.showToast("您还未安装微信客户端");
            return;
        }
        final SendAuth.Req req = new SendAuth.Req();
        req.scope = scope;
        req.state = state;
        mWxApi.sendReq(req);
    }

    public void shareLinkToChatScene(String link, String title, String desc) {
        WXWebpageObject webpage = new WXWebpageObject();
        webpage.webpageUrl = link;//分享url
        WXMediaMessage msg = new WXMediaMessage(webpage);
        msg.title = title;
        msg.description = desc;
        Bitmap bitmap = BitmapFactory.decodeResource(this.getResources(), R.drawable.icon80x80);
        msg.setThumbImage(bitmap);

        SendMessageToWX.Req req = new SendMessageToWX.Req();
        req.transaction = String.valueOf(System.currentTimeMillis());
        req.message = msg;
        req.scene = SendMessageToWX.Req.WXSceneSession;
        mWxApi.sendReq(req);
    }

    public void shareImageChatScene(Bitmap bitmap) {
        WXImageObject imgObj = new WXImageObject(bitmap);

        WXMediaMessage msg = new WXMediaMessage();
        msg.mediaObject = imgObj;

        //Bitmap thumbBitmap =  Bitmap.createScaledBitmap(bitmap, THUMB_SIZE, THUMB_SIZE, true);
        //bitmap.recycle();
        //msg.setThumbImage(thumbBitmap);  //设置缩略图

        SendMessageToWX.Req req = new SendMessageToWX.Req();
        req.transaction = "imgshareappdata";
        req.message = msg;
        req.scene = SendMessageToWX.Req.WXSceneSession;
        mWxApi.sendReq(req);
    }

    // 对cocos glview 没用
    public Bitmap screenShotWholeScreen() {
        View dView = getGLSurfaceView();
        dView.setDrawingCacheEnabled(true);
        dView.buildDrawingCache();
        Bitmap bitmap = Bitmap.createBitmap(dView.getDrawingCache());
        return bitmap;
    }

    private Bitmap createBitmapFromGLSurface(int x, int y, int w, int h, GL10 gl) throws OutOfMemoryError {
        int bitmapBuffer[] = new int[w * h];
        int bitmapSource[] = new int[w * h];
        IntBuffer intBuffer = IntBuffer.wrap(bitmapBuffer);
        intBuffer.position(0);

        try {
            gl.glReadPixels(x, y, w, h, GL10.GL_RGBA, GL10.GL_UNSIGNED_BYTE,
                    intBuffer);
            int offset1, offset2;

            for (int i = 0; i < h; i++) {
                offset1 = i * w;
                offset2 = (h - i - 1) * w;
                for (int j = 0; j < w; j++) {
                    int texturePixel = bitmapBuffer[offset1 + j];
                    int blue = (texturePixel >> 16) & 0xff;
                    int red = (texturePixel << 16) & 0x00ff0000;
                    int pixel = (texturePixel & 0xff00ff00) | red | blue;
                    bitmapSource[offset2 + j] = pixel;
                }
            }
        } catch (GLException e) {
            return null;
        }

        return Bitmap.createBitmap(bitmapSource, w, h, Bitmap.Config.ARGB_8888);
    }


    public Bitmap getScreenShot() {
        Cocos2dxGLSurfaceView glSurView = getGLSurfaceView();
        // 这个方法是自己添加的.修改了Cocos2dxGLSurfaceView.java和Cocos2dxRenderer.java onDrawFrame()
        GL10 g1 = glSurView.getGlHandler();
        int w = glSurView.getWidth();
        int h = glSurView.getHeight();

        Bitmap bmp = createBitmapFromGLSurface(0, 0, w, h, g1);
        return bmp;
    }


    public String judgeProvider(LocationManager locationManager) {
        List<String> prodiverlist = locationManager.getProviders(true);
        if (prodiverlist.contains(LocationManager.NETWORK_PROVIDER)) {
            return LocationManager.NETWORK_PROVIDER;//网络定位
        } else if (prodiverlist.contains(LocationManager.GPS_PROVIDER)) {
            return LocationManager.GPS_PROVIDER;//GPS定位
        } else {
            //Toast.makeText(activity.getMyContext(),"没有可用的位置提供器",Toast.LENGTH_SHORT).show();
        }
        return null;
    }

    public void beginLocatioon() {
//        if (!isCreated) {
//            toGetLocation = true;
//            return;
//        }

        Location location = null;
        boolean requesting = false;
        //获得位置服务
        String provider = judgeProvider(locationManager);
        //有位置提供器的情况
        if (provider != null) {
            // 检查权限
            if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP_MR1) {
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED
                        && ActivityCompat.checkSelfPermission(this.getApplicationContext(), Manifest.permission.ACCESS_COARSE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {
                    return;
                }
            }
            location = locationManager.getLastKnownLocation(provider);

            if (location == null) {
                locationManager.requestLocationUpdates(provider, 10000, 100, new LocationListener() {
                    @Override
                    public void onLocationChanged(Location location) {
                        runJs("onLocation(" + "true" + ", " + location.getLatitude() + ", " + location.getLongitude() + ");");
                        locationManager.removeUpdates(this);
                    }

                    @Override
                    public void onStatusChanged(String provider, int status, Bundle extras) {

                    }

                    @Override
                    public void onProviderEnabled(String provider) {

                    }

                    @Override
                    public void onProviderDisabled(String provider) {

                    }
                });
                requesting = true;
            }
        } else {
            //不存在位置提供器的情况
            //Toast.makeText(activity.getMyContext(),"不存在位置提供器的情况",Toast.LENGTH_SHORT).show();
        }
        if (!requesting) {
            if (location == null) {
                runJs("onLocation(true, 0.0, 0.0);");
            } else {
                runJs("onLocation(" + "false" + ", " + location.getLatitude() + ", " + location.getLongitude() + ");");
            }
        }
    }

    public void startRecord(String path, float during) {
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP_MR1) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                //this.requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},
                //        RECORD_AUDIO);
                // 提示没有开启话筒权限
                runJs("onMicrophoneAuth(false)");
                return;
            }
        }

        if (isRecording) {
            return;
        }

        if (mediaRecorder == null) {
            mediaRecorder = new MediaRecorder();
        } else {
            mediaRecorder.reset();
        }

        //File audioFile;

        //File mpath = new File(path);
        //boolean b = mpath.mkdirs();

        try {
            //audioFile = File.("record",".aac", mpath);

            mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);

            mediaRecorder.setOutputFile(path + "record.aac");
            mediaRecorder.prepare();
            mediaRecorder.start();
            isRecording = true;

            if (runnableRec == null) {
                runnableRec = new Runnable() {
                    @Override
                    public void run() {
                        //要做的事情
                        if (isRecording) {
                            mediaRecorder.stop();
                            isRecording = false;
                            runJs("onRecord(\"record.aac\")");
                        }
                    }
                };
            }
            handler.postDelayed(runnableRec, (long) (during * 1000));
        } catch (IOException e) {
            e.printStackTrace();
        } catch (IllegalStateException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void stopRecord() {
        if (mediaRecorder == null) {
            return;
        }
        if (!isRecording) {
            return;
        }
        try {
            mediaRecorder.stop();
            isRecording = false;
            handler.removeCallbacks(runnableRec);
            runJs("onRecord(\"record.aac\")");
        } catch (IllegalStateException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void playSound(String fileName) {
        if (mediaPlayer == null) {
            mediaPlayer = new MediaPlayer();
        } else {
            mediaPlayer.reset();
        }
        try {
            mediaPlayer.setDataSource(fileName);
            mediaPlayer.prepare();
            mediaPlayer.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void WxLogin(String scope, String state) {
        instance.wxLogin(scope, state);
    }

    public static void ShareLinkToChatScene(String link, String title, String desc) {
        instance.shareLinkToChatScene(link, title, desc);
    }

    public static void ShareImageChatScene(String path) {

    }

    public static void ShareScreenToChatScene() {
        Bitmap bitmap = instance.getScreenShot();
        instance.shareImageChatScene(bitmap);
    }

    public static void GetLocation() {
        instance.beginLocatioon();

    }

    public static void StartRecord(String path, float during) {
        instance.startRecord(path, during);
    }

    public static void StopRecord() {
        instance.stopRecord();
    }

    /**
     * 全路径
     *
     * @param fileName
     */
    public static void PlaySound(String fileName) {
        instance.playSound(fileName);
    }

    /**
     * 显示网络类型，回调js方法
     *
     * @param networkType
     */
    @Override
    public void onNetConnected(int networkType) {
        String netWorkString = "";
        boolean needConnect = false;
//        ""是 无,   "wifi" 是wifi,  "wwan"是2g/3g/4g
        switch (networkType) {

            case Constants.NETWORK_TYPE_UNCONNECTED:
            case Constants.NETWORK_TYPE_UNKNOWN:
                netWorkString = "";
                needConnect = true;
                break;

            case Constants.NETWORK_TYPE_WIFI:
                netWorkString = "wifi";
                needConnect = false;
                break;

            case Constants.NETWORK_TYPE_2G:
            case Constants.NETWORK_TYPE_3G:
            case Constants.NETWORK_TYPE_4G:
                netWorkString = "wwan";
                needConnect = false;
                break;
        }

        runJs("onNetwork(\\\"" + netWorkString + "\\\",\\\"" + needConnect + "\\\");");
        Log.e("tgmj", " tgmj " +  netWorkString + "," + needConnect);
    }


    /**
     * 震动
     */
    public static void Vibrate() {
        VibratorUtil.Vibrate(instance, 500);
    }
    /**
     * 震动
     */
    public static void Vibrate(int millisecond) {
        VibratorUtil.Vibrate(instance, millisecond);
    }

    /**
     *摇一摇事件监听 回调js
     */
    public static void shake(){
        runJs("onShake(\\\"\\\");");
    }

    private void registerShakeListener(){
        SensorManager sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        sensorManager.registerListener(new SensorEventListener(){
            /**
             * 检测的时间间隔
             */
            static final int UPDATE_INTERVAL = 100;
            /**
             * 上一次检测的时间
             */
            long mLastUpdateTime;
            /**
             * 上一次检测时，加速度在x、y、z方向上的分量，用于和当前加速度比较求差。
             */
            float mLastX, mLastY, mLastZ;

            /**
             * 摇晃检测阈值，决定了对摇晃的敏感程度，越小越敏感。
             */
            public int shakeThreshold = 2500;

            @Override
            public void onSensorChanged(SensorEvent event) {
                long currentTime = System.currentTimeMillis();
                long diffTime = currentTime - mLastUpdateTime;
                if (diffTime < UPDATE_INTERVAL) {
                    return;
                }
                mLastUpdateTime = currentTime;
                float x = event.values[0];
                float y = event.values[1];
                float z = event.values[2];
                float deltaX = x - mLastX;
                float deltaY = y - mLastY;
                float deltaZ = z - mLastZ;
                mLastX = x;
                mLastY = y;
                mLastZ = z;
                float delta = (float) (Math.sqrt(deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ) / diffTime * 10000);
                // 当加速度的差值大于指定的阈值，认为这是一个摇晃
                if (delta > shakeThreshold) {
                    Vibrate();
                    shake();
                }
            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int i) {

            }
        }, sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), sensorManager.SENSOR_DELAY_NORMAL);

    }
}
