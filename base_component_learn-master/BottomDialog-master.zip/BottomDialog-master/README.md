# Android底部对话框BottomDialog
![](https://github.com/xiaoyanger0825/BottomDialog/raw/master/images/a.gif)
![](https://github.com/xiaoyanger0825/BottomDialog/raw/master/images/b.gif)